
Kinect Chapter 6. The Tilt Motor, LED, and Accelerometer

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 4 Java files:
  * MotorTest.java
  * MotorCommunicator.java, LEDStatus.java, MotorStatus.java

Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for libusbjava;

One JAR file:
  * ch.ntb.usb-0.5.9_REVISED.jar
      - this is a replacement for ch.ntb.usb-0.5.9.jar which is part
        of LibUsbJava (see next section)


----------------------------
Before Compilation/Execution:

You should download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.

[ Strictly speaking 1-3 aren't needed for this example, which only uses
libusb-win32 and libusbjava, but you'll need them for all other Kinect
programming. ]

Also download and install:

   * libusb-win32: http://sourceforge.net/apps/trac/libusb-win32/wiki
             I downloaded libusb-win32-bin-1.2.4.0.zip
             --> The executable installs libusb-win32 into c:\Program Files\LibUSB-Win32\
             --> copy and rename the relevant DLLs in bin\ over to the OS
                   e.g. libusb0_x86.dll --> Windows\system32\libusb0.dll 
                        libusb0.sys --> Windows\systems32\drivers\libusb0.sys

   * libusbjava: http://libusbjava.sourceforge.net/wp/
             I downloaded ch.ntb.usb-0.5.9.jar and LibusbJava_dll_0.2.4.0.zip
             --> move the JAR and unzipped DLL to c:\LibUsbJava

             --> replace ch.ntb.usb-0.5.9.jar with my ch.ntb.usb-0.5.9_REVISED.jar,
                 renaming it to ch.ntb.usb-0.5.9.jar

----------------------------
Other requirements:

  * plug the Kinect into a power source and a USB port of the PC

  * Create a libusb-win32 device driver for the Kinect motor using libusb-win32's
    inf-wizard.exe (see the chapter, section 1, for details)

----------------------------
Compilation:

> compile *.java
    // you must have libusb-win32, libusbjava, and your motor driver installed;

----------------------------
Execution:

> run MotorTest
    - this tries to find, open, and close the Kinect motor

> run MotorCommunicator
    - this prompts the user for tilt angles, until the user types 'q'

    // you must have libusb-win32, libusbjava, and your motor driver installed;

---------------------------------
Last updated: 1st November 2011
