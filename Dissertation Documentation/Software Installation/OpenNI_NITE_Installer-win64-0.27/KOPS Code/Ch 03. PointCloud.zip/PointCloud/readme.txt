
Kinect Chapter 3. A Point Cloud for Depths

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 6 Java files:
  *  PointCloud.java, Points3DPanel.java,
     PointsShape.java, DepthReader.java,
     CheckerFloor.java, ColouredTiles.java


Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI;
     - colorutils.jar must be in this directory


One JAR file:
  * colorutils.jar
      - from http://code.google.com/p/colorutils/


----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.

You will also need:
    4.  Java 3D  (http://java3d.java.net/)


----------------------------
Compilation:

> compile *.java
    // you must have Java 3D, OpenNI, the SensorKinect driver, and NITE installed;
    // colorutils.jar must be in this directory

----------------------------
Execution:

> run PointCloud
    // you must have Java 3D, OpenNI, the SensorKinect driver, and NITE installed;
    // colorutils.jar must be in this directory

---------------------------------
Last updated: 17th February 2012
