
Kinect Chapters 1 and 2. Kinect Imaging

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================


This directory contains 2 Java files:
  *  OpenNIViewer.java, 
     ViewerPanel.java
           - this is ViewerPanel version 1


There are 6 subdirectories, whih contain different versions
of ViewerPanel:
  * version_1\   - draws a grayscale depth map with XML config file 
  * version_2\   - draws a grayscale depth map with run time Context object
  * version_3\   - shows a camera image map
  * version_4\   - renders an IR map
  * version_5\   - draws a colorized depth map
  * version_6\   - shows a combined colorized depth and camera image


Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI;
     - colorutils.jar must be in this directory



One XML file:
  *  SamplesConfig.xml
       - used by version 1


One JAR file:
  * colorutils.jar
      - from http://code.google.com/p/colorutils/
      - used by versions 5 and 6


----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.


----------------------------
Compilation:

Copy the version of ViewerPanel.java that you want to try from the 
correct version <number>\ subdirectory.

> compile *.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed;
    // colorutils.jar must be in this directory

----------------------------
Execution:

> run OpenNIViewer
    // you must have OpenNI, the SensorKinect driver, and NITE installed;
    // colorutils.jar must be in this directory

----------------------------
Last updated: 15th September 2011
