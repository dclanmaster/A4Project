
Kinect Chapter 4. Tracking Users in 2D

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 3 Java files:
  * GorillasTracker.java, TrackerPanel.java,
    Skeletons.java

One image file:
  * gorilla.png

Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI;



----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.


----------------------------
Compilation:

> compile *.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

----------------------------
Execution:

> run GorillasTracker
    // you must have OpenNI, the SensorKinect driver, and NITE installed;
    // remember to assume the "psi" position, so tracking can start
       e.g. like the user on the left of Figure 1

---------------------------------
Last updated: 28th February 2012
