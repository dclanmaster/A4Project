
Kinect Chapter 9 Kinect Breakout

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 7 Java files:
  * Breakout.java, BreakoutPanel.java,
    BricksManager.java, Brick.java,
    Ball.java, Paddle.java, Sprite.java

There is 1 subdirectory containing game graphics (8 PNG files):
  * images/

Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI and NITE;

----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.

----------------------------
Compilation:

> compile *.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

----------------------------
Execution:

> run Breakout
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

    // you start the game with a "click" focus gesture --
       push the flat of your hand at the Kinect (in the same way as a "push"
       gesture), or by waving

    // the game pauses if the Kinect cannot detect a hand

    // if a hand is not detected for 60 secs, then the game will terminate

    // hand refocusing is done with a click, wave, or hand raising,
       and the game will resume

    // you can use the keys ESC, 'q', and ctrl-c to terminate the game,
       and 'p' to pause/resume


---------------------------------
Last updated: 27th November 2011
