
Kinect Chapter 7. NITE Hand Gestures

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 2 Java files:
  * GestureDetect.java, PositionInfo.java

Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI and NITE;



----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.


----------------------------
Compilation:

> compile *.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

----------------------------
Execution:

> run GestureDetect
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

    // you start the gesture tracking session with a "click" focus gesture --
       push the flat of your hand at the Kinect (in the same way as a "push"
       gesture

---------------------------------
Last updated: 10th November 2011
