
Kinect Chapter 8. NITE Hands Tracker

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 3 Java files:
  * HandsTracker.java, TrackerPanel.java, HandTrail.java

Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI and NITE;

----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.

----
You must edit Nite.ini in C:\Program Files\PrimeSense\NITE\Hands_1_4_0\Data
(or whatever the latest version of Hands_XXX\ is called) to allow NITE 
to track multiple hands. Uncommented both property lines, so the file contains:

[HandTrackerManager]
AllowMultipleHands=1
TrackAdditionalHands=1


----------------------------
Compilation:

> compile *.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

----------------------------
Execution:

> run HandsTracker
    // you must have OpenNI, the SensorKinect driver, and NITE installed;

    // you start the hands tracking session with a "click" focus gesture --
       push the flat of your hand at the Kinect (in the same way as a "push"
       gesture), or by waving

    // other hands are recognized by bringing them close to the first hand

    // hand refocusing can be done with a click, wave, or hand raising


---------------------------------
Last updated: 15th November 2011
