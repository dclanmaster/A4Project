
Kinect Chapter 5.  Viewing Users in 3D

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains 9 Java files:
  *  UsersViewer3D.java, TrackerPanel3D.java,
     SkelsManager.java, Skeleton3D.java,
     Joint3D.java, Limb3D.java, SmoothPosition.java,
     CheckerFloor.java, ColouredTiles.java


Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI;



----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 13, or installInfo.txt
in this directory.

You will also need:
    4.  Java 3D  (http://java3d.java.net/)


----------------------------
Compilation:

> compile *.java
    // you must have Java 3D, OpenNI, the SensorKinect driver, and NITE installed;

----------------------------
Execution:

> run UsersViewer3D
    // you must have Java 3D, OpenNI, the SensorKinect driver, and NITE installed;

    // remember to assume the "psi" position, so tracking can start
       e.g. like the user in the middle of Figure 1

---------------------------------
Last updated: 12th October 2011
