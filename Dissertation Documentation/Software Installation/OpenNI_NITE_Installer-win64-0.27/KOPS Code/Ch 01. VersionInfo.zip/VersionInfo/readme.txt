
Kinect Chapter 1. Getting Started

From the website:

  Kinect Open Source Programming Secrets
  http://fivedots.coe.psu.ac.th/~ad/kinect/

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================


This directory contains 1 Java file:
  *  VersionInfo.java, 


Two batch files:
  *  compile.bat
  *  run.bat
     - make sure they refer to the correct location for OpenNI;


----------------------------
Before Compilation/Execution:

You need to download and install:
    1.	OpenNI
    2.	SensorKinect driver
    3.	NITE

For details, read section 3 of Chapter 2, or installInfo.txt
in this directory.


----------------------------
Compilation:

> compile VersionInfo.java
    // you must have OpenNI, the SensorKinect driver, and NITE installed

----------------------------
Execution:

> run VersionInfo
    // you must have OpenNI, the SensorKinect driver, and NITE installed

----------------------------
Last updated: 16th February 2012
